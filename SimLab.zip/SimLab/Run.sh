cd ./Resources/CycloneSource
make Cyclone64
cp Cyclone64 ../Cyclone64
cd ../..
java -jar PlantSimLab.jar
