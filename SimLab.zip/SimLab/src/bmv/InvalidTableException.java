package bmv;

public class InvalidTableException extends Exception {

	String message = "INVALID TABLE HEADER";
}
